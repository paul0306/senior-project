package com.example.house

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.Toast
import androidx.core.view.get
import com.example.house.databinding.ActivityPage3Binding

class Activity_page3 : AppCompatActivity() {
    private lateinit var binding: ActivityPage3Binding
    private val mOnCheckedChangeListener = CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
        when (buttonView.id) {
            R.id.tb_elevator -> Toast.makeText(this, "elevator is $isChecked", Toast.LENGTH_SHORT).show()
            R.id.tb_manage -> Toast.makeText(this, "manage is $isChecked", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPage3Binding.inflate(layoutInflater)
        setContentView(binding.root)
        var inputList = mutableListOf<String>()
        var city = intent.getStringExtra("Text").toString()
        inputList.add(city)
        var output = binding.textView
        binding.tbElevator.setOnCheckedChangeListener(mOnCheckedChangeListener)
        binding.tbManage.setOnCheckedChangeListener(mOnCheckedChangeListener)
        /*var elevator = binding.tbElevator
        elevator.setOnClickListener { buttonView, isChecked ->
             Toast.makeText(this, "elevator is $isChecked", Toast.LENGTH_SHORT).show()
        }*/

        var spinner = binding.spinner
        val type = arrayListOf("大樓", "透天")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, type)
        spinner.adapter = adapter

        var longitude = binding.etLongitude.toString()
        var latitude = binding.etLatitude.toString()
        var age = binding.etAge.toString()
        var space = binding.etSpace.toString()
        var room = binding.etRoom.toString()
        var livingroom = binding.etLivingroom.toString()
        var bathroom = binding.etBathroom.toString()
        var car = binding.etCar.toString()

        binding.btLast.setOnClickListener {
            output.text = spinner
        }
        if (longitude == null) {
            Toast.makeText(this, "尚未輸入房屋經度", Toast.LENGTH_SHORT).show()
        }
        if (latitude == null) {
            Toast.makeText(this, "尚未輸入房屋緯度", Toast.LENGTH_SHORT).show()
        }
        if (age == null) {
            Toast.makeText(this, "尚未輸入房屋年齡", Toast.LENGTH_SHORT).show()
        }
        if (space == null) { //如未輸入，則顯示警告文字"尚未輸入房屋總坪數"
            Toast.makeText(this, "尚未輸入房屋總坪數", Toast.LENGTH_SHORT).show()
        }
        if (room == null) { //如未輸入，則顯示警告文字"尚未輸入房間總數"
            Toast.makeText(this, "尚未輸入房間總數", Toast.LENGTH_SHORT).show()
        }
        if (livingroom == null) { //如未輸入，則顯示警告文字"尚未輸入總廳數"
            Toast.makeText(this, "尚未輸入總廳數", Toast.LENGTH_SHORT).show()
        }
        if (bathroom == null) { //如未輸入，則顯示警告文字"尚未輸入衛生間總數"
            Toast.makeText(this, "尚未輸入衛生間總數", Toast.LENGTH_SHORT).show()
        }
        if (car == null) { //如未輸入，則顯示警告文字"尚未輸入車位總數"
            Toast.makeText(this, "尚未輸入車位總數", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(longitude)
            inputList.add(latitude)
            inputList.add(age)
            inputList.add(space)
            inputList.add(room)
            inputList.add(livingroom)
            inputList.add(bathroom)
            inputList.add(car)
        }
    }

}
