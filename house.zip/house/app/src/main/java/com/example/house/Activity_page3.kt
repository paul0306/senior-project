package com.example.house

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.core.view.get
import com.example.house.databinding.ActivityPage3Binding
import okhttp3.FormBody
import okhttp3.*
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread

class Activity_page3 : AppCompatActivity() {
    private lateinit var binding: ActivityPage3Binding
    private var inputList = mutableListOf<String>()
    /*private val mOnCheckedChangeListener = CompoundButton.OnCheckedChangeListener { buttonView, isChecked ->
        when (buttonView.id) {
            R.id.tb_elevator -> Toast.makeText(this, "elevator is $isChecked", Toast.LENGTH_SHORT).show()
            R.id.tb_manage -> Toast.makeText(this, "manage is $isChecked", Toast.LENGTH_SHORT).show()
        }
    }*/
    private fun postData(inputList: List<String>) {
        val queue = LinkedBlockingQueue<String>()
        val url = "http://oldpai.im.ncnu.edu.tw/api"

        val body = FormBody.Builder()
            .add("latA", inputList[0])
            .add("longA", inputList[1])
            .add("city", inputList[2])
            .add("houseType", inputList[3])
            .add("area", inputList[4])
            .add("age", inputList[5])
            .add("story", inputList[6])
            .add("park", inputList[7])
            .add("room", inputList[8])
            .add("living", inputList[9])
            .add("bath", inputList[10])
            .add("org", inputList[11])
            .add("elev", inputList[12])
            .build()
        thread {
            val client = OkHttpClient()
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()
            var response = client.newCall(request).execute()
            var responseData = response.body?.string()
            val itemList = JSONObject(responseData)
            val price = itemList.get("price").toString()
            queue.add(price)
        }
        binding.textView.text = queue.take()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPage3Binding.inflate(layoutInflater)
        setContentView(binding.root)

        var city = intent.getStringExtra("Text").toString()

        var spinner = binding.spinner
        val type = arrayListOf("大樓", "透天")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, type)
        spinner.adapter = adapter
        var houseType = spinner.selectedItem.toString()

        binding.btLast.setOnClickListener {

            var story = binding.etStory.toString()
            var longitude = binding.etLongitude.toString()
            var latitude = binding.etLatitude.toString()
            var age = binding.etAge.toString()
            var space = binding.etSpace.toString()
            var room = binding.etRoom.toString()
            var livingroom = binding.etLivingroom.toString()
            var bathroom = binding.etBathroom.toString()
            var car = binding.etCar.toString()

            /*binding.tbElevator.setOnCheckedChangeListener(mOnCheckedChangeListener)
            binding.tbManage.setOnCheckedChangeListener(mOnCheckedChangeListener)*/

            var manage: String
            var elevator: String
            if (binding.tbManage.isChecked) {
                manage = "1"
            } else {
                manage = "0"
            }
            if (binding.tbElevator.isChecked) {
                elevator = "1"
            } else {
                elevator = "0"
            }

            /*if (story == null) {
                Toast.makeText(this, "尚未輸入樓高", Toast.LENGTH_SHORT).show()
            }
            if (longitude == null) {
                Toast.makeText(this, "尚未輸入房屋經度", Toast.LENGTH_SHORT).show()
            }
            if (latitude == null) {
                Toast.makeText(this, "尚未輸入房屋緯度", Toast.LENGTH_SHORT).show()
            }
            if (age == null) {
                Toast.makeText(this, "尚未輸入房屋年齡", Toast.LENGTH_SHORT).show()
            }
            if (space == null) { //如未輸入，則顯示警告文字"尚未輸入房屋總坪數"
                Toast.makeText(this, "尚未輸入房屋總坪數", Toast.LENGTH_SHORT).show()
            }
            if (room == null) { //如未輸入，則顯示警告文字"尚未輸入房間總數"
                Toast.makeText(this, "尚未輸入房間總數", Toast.LENGTH_SHORT).show()
            }
            if (livingroom == null) { //如未輸入，則顯示警告文字"尚未輸入總廳數"
                Toast.makeText(this, "尚未輸入總廳數", Toast.LENGTH_SHORT).show()
            }
            if (bathroom == null) { //如未輸入，則顯示警告文字"尚未輸入衛生間總數"
                Toast.makeText(this, "尚未輸入衛生間總數", Toast.LENGTH_SHORT).show()
            }
            if (car == null) { //如未輸入，則顯示警告文字"尚未輸入車位總數"
                Toast.makeText(this, "尚未輸入車位總數", Toast.LENGTH_SHORT).show()
            }
            else {
                inputList.add(latitude)
                inputList.add(longitude)
                inputList.add(city)
                inputList.add(houseType)
                inputList.add(space)
                inputList.add(age)
                inputList.add(story)
                inputList.add(car)
                inputList.add(room)
                inputList.add(livingroom)
                inputList.add(bathroom)
                inputList.add(manage)
                inputList.add(elevator)
                postData(inputList)
            }*/
            binding.textView.text = latitude
        }
    }

}
