package com.example.house

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.house.databinding.ActivityMainBinding
import com.example.house.databinding.ActivityPage2Binding

class Activity_page2 : AppCompatActivity() {
    private lateinit var binding: ActivityPage2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPage2Binding.inflate(layoutInflater)
        setContentView(binding.root)
        var taipei = binding.btTaipei
        taipei.setOnClickListener {
            var intent = Intent(this, Activity_page3::class.java)
            intent.putExtra("Text", "tpe")
            startActivity(intent)
        }
        var Newtaipei = binding.btNewTaipei
        Newtaipei.setOnClickListener {
            var intent = Intent(this, Activity_page3::class.java)
            intent.putExtra("Text", "tpe")
            startActivity(intent)
        }
        var taoyuan = binding.btTaoyuan
        taoyuan.setOnClickListener {
            var intent = Intent(this, Activity_page3::class.java)
            intent.putExtra("Text", "tyn")
            startActivity(intent)
        }
        var taichung = binding.btTaichung
        taichung.setOnClickListener {
            var intent = Intent(this, Activity_page3::class.java)
            intent.putExtra("Text", "txg")
            startActivity(intent)
        }
        var tainan = binding.btTainan
        tainan.setOnClickListener {
            var intent = Intent(this, Activity_page3::class.java)
            intent.putExtra("Text", "tnn")
            startActivity(intent)
        }
        var kaosiung = binding.btKaosiung
        kaosiung.setOnClickListener {
            var intent = Intent(this, Activity_page3::class.java)
            intent.putExtra("Text", "khh")
            startActivity(intent)
        }
    }
}