package com.example.testhttp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Message
import android.util.Log
import com.example.testhttp.databinding.ActivityMainBinding
import okhttp3.FormBody
import okhttp3.*
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.calculate.setOnClickListener { postData() }
    }
    private fun postData() {

        var latA = binding.latA.text.toString()
        var longA = binding.longA.text.toString()
        var city = binding.city.text.toString()
        var houseType = binding.houseType.text.toString()
        var area = binding.area.text.toString()
        var age = binding.age.text.toString()
        var story = binding.story.text.toString()
        var park = binding.park.text.toString()
        var room = binding.room.text.toString()
        var living = binding.living.text.toString()
        var bath = binding.bath.text.toString()
        var org = binding.org.text.toString()
        var elev = binding.elev.text.toString()

        val queue = LinkedBlockingQueue<String>()

        val url = "http://oldpai.im.ncnu.edu.tw/api"

        val body = FormBody.Builder()
            .add("latA", latA)
            .add("longA", longA)
            .add("city", city)
            .add("houseType", houseType)
            .add("area", area)
            .add("age", age)
            .add("story", story)
            .add("park", park)
            .add("room", room)
            .add("living", living)
            .add("bath", bath)
            .add("org", org)
            .add("elev", elev)
            .build()

        thread {
            val client = OkHttpClient()
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()
            var response = client.newCall(request).execute()
            var responseData = response.body?.string()
            val itemList = JSONObject(responseData)
            val price = itemList.get("price").toString()
            Log.v("calculate", "$price")
            queue.add(price)
        }
        binding.price.text = latA
    }
}