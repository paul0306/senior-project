package com.example.housepredict

import android.annotation.SuppressLint
import android.content.SharedPreferences.Editor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.*

class page3 : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page3)
        val inputList = mutableListOf<String>() //宣告一個可變動之 List，用於存放輸入資料
        val city = intent.getStringExtra("Text").toString() //將前一頁面攜帶之 String，加入至 inputList
        inputList.add(city)

        val build = RadioButton(this) //宣告大樓選擇鈕
        val house = RadioButton(this) //宣告透天厝選擇鈕
        val group = RadioGroup(this) //宣告選擇鈕團體，讓使用者只能單選選擇紐
        val houseType = group.findViewById<RadioButton>(group.checkedRadioButtonId).text //check使用者選擇甚麼鈕
        if (houseType == "大樓") { //如為大樓，則在 inputList中加入名為大樓之 String
            inputList.add("大樓")
        }
        if (houseType == "透天厝") { //如為透天厝，則在 inputList中加入名為透天厝之 String
            inputList.add("透天厝")
        }
        if (houseType == null) { //如未選擇，則顯示警告文字"請選擇房屋類型"
            Toast.makeText(this, "請選擇房屋類型", Toast.LENGTH_SHORT).show()
        }

        val editView_longitude: EditText //宣告經度輸入
        editView_longitude = findViewById(R.id.textView_longitude) //讀取輸入內容
        val longitude = editView_longitude.toString() //將輸入內容轉成 String
        if (longitude == null) { //如未輸入，則顯示警告文字"尚未輸入房屋經度"
            Toast.makeText(this, "尚未輸入房屋經度", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(longitude) //將輸入內容加入至 inputList
        }

        val editView_latitude: EditText //宣告緯度輸入
        editView_latitude = findViewById(R.id.textView_latitude) //讀取輸入內容
        val latitude = editView_latitude.toString() //將輸入內容轉成 String
        if (latitude == null) { //如未輸入，則顯示警告文字"尚未輸入房屋緯度"
            Toast.makeText(this, "尚未輸入房屋緯度", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(latitude) //將輸入內容加入至 inputList
        }

        val editText_ageInput: EditText //宣告屋齡輸入
        editText_ageInput = findViewById(R.id.editText_ageInput) //讀取輸入內容
        val ageInput = editText_ageInput.toString() //將輸入內容轉成 String
        if (ageInput == null) { //如未輸入，則顯示警告文字"尚未輸入房屋年齡"
            Toast.makeText(this, "尚未輸入房屋年齡", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(ageInput) //將輸入內容加入至 inputList
        }

        val editText_houseSpace: EditText //宣告總坪數輸入
        editText_houseSpace = findViewById(R.id.editText_houseSpace) //讀取輸入內容
        val houseSpace = editText_houseSpace.toString() //將輸入內容轉成 String
        if (houseSpace == null) { //如未輸入，則顯示警告文字"尚未輸入房屋總坪數"
            Toast.makeText(this, "尚未輸入房屋總坪數", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(houseSpace) //將輸入內容加入至 inputList
        }

        val editText_roomNum: EditText //宣告房間數輸入
        editText_roomNum = findViewById(R.id.editText_roomNum) //讀取輸入內容
        val roomNum = editText_roomNum.toString() //將輸入內容轉成 String
        if (roomNum == null) { //如未輸入，則顯示警告文字"尚未輸入房間總數"
            Toast.makeText(this, "尚未輸入房間總數", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(roomNum) //將輸入內容加入至 inputList
        }

        val editText_livingroom: EditText //宣告廳數輸入
        editText_livingroom = findViewById(R.id.editText_livingroom) //讀取輸入內容
        val livingroom = editText_livingroom.toString() //將輸入內容轉成 String
        if (livingroom == null) { //如未輸入，則顯示警告文字"尚未輸入總廳數"
            Toast.makeText(this, "尚未輸入總廳數", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(livingroom) //將輸入內容加入至 inputList
        }

        val editText_bathroom: EditText //宣告衛生間數輸入
        editText_bathroom = findViewById(R.id.editText_bathroom) //讀取輸入內容
        val bathroom = editText_bathroom.toString() //將輸入內容轉成 String
        if (bathroom == null) { //如未輸入，則顯示警告文字"尚未輸入衛生間總數"
            Toast.makeText(this, "尚未輸入衛生間總數", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(bathroom) //將輸入內容加入至 inputList
        }

        val editText_carInput: EditText //宣告車位數輸入
        editText_carInput = findViewById(R.id.editText_carInput) //讀取輸入內容
        val carInput = editText_carInput.toString() //將輸入內容轉成 String
        if (carInput == null) { //如未輸入，則顯示警告文字"尚未輸入車位總數"
            Toast.makeText(this, "尚未輸入車位總數", Toast.LENGTH_SHORT).show()
        }
        else {
            inputList.add(carInput) //將輸入內容加入至 inputList
        }

        val elevator: Switch //宣告電梯確認開關
        elevator = findViewById(R.id.elevator)  //讀取輸入內容
        //如果為開啟狀態，則加入 true之 String至 inputList中
        elevator.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked == true) {
                inputList.add("true")
            }
            else {
                inputList.add("false") //否則加入 false之 String至 inputList
            }
        }

        val management: Switch //宣告管理組織確認開關
        management = findViewById(R.id.elevator)  //讀取輸入內容
        //如果為開啟狀態，則加入 true之 String至 inputList中
        management.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked == true) {
                inputList.add("true")
            }
            else {
                inputList.add("false") //否則加入 false之 String至 inputList
            }
        }
    }
}