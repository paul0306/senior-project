package com.example.housepredict

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class page2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page2)
            mutableListOf("Taipei", "newTaipei", "Taoyuan", "Taichung", "Tainan", "Kaosiung") //設六都城市之 List
        val button_taipei: Button = findViewById(R.id.button_taipei) //宣告台北市按鈕
        button_taipei.setOnClickListener { //當台北市按鈕被點擊，跳至下一頁面，並攜帶名為台北市之 String至下一頁面
            val intent = Intent(this, page3::class.java)
            intent.putExtra("Text", "Taipei")
            startActivity(intent)
        }
        val button_newtaipei: Button = findViewById(R.id.button_newtaipei) //宣告新北市按鈕
        button_newtaipei.setOnClickListener { //當新北市按鈕被點擊，跳至下一頁面，並攜帶名為台北市之 String至下一頁面，因雙北皆是使用同一模型，故攜帶台北市之 String
            val intent = Intent(this, page3::class.java)
            intent.putExtra("Text", "Taipei")
            startActivity(intent)
        }
        val button_taoyuan: Button = findViewById(R.id.button_taoyuan) //宣告桃園市按鈕
        button_taoyuan.setOnClickListener { //當桃園市按鈕被點擊，跳至下一頁面，並攜帶名為桃園市之 String至下一頁面
            val intent = Intent(this, page3::class.java)
            intent.putExtra("Text", "Taoyuan")
            startActivity(intent)
        }
        val button_taichung: Button = findViewById(R.id.button_taichung) //宣告台中市按鈕
        button_taichung.setOnClickListener { //當台中市按鈕被點擊，跳至下一頁面，並攜帶名為台中市之 String至下一頁面
            val intent = Intent(this, page3::class.java)
            intent.putExtra("Text", "Taichung")
            startActivity(intent)
        }
        val button_tainan: Button = findViewById(R.id.button_tainan) //宣告台南市按鈕
        button_tainan.setOnClickListener { //當台南市按鈕被點擊，跳至下一頁面，並攜帶名為台南市之 String至下一頁面
            val intent = Intent(this, page3::class.java)
            intent.putExtra("Text", "Tainan")
            startActivity(intent)
        }
        val button_kaosiung: Button = findViewById(R.id.button_kaosiung) //宣告高雄市按鈕
        button_kaosiung.setOnClickListener { //當高雄市按鈕被點擊，跳至下一頁面，並攜帶名為高雄市之 String至下一頁面
            val intent = Intent(this, page3::class.java)
            intent.putExtra("Text", "Kaosiung")
            startActivity(intent)
        }
    }
}